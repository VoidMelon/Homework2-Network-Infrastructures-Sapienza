i know that it didn't move the id_rsa_pub into into the folder of the authorized keys of s2, but if kathara doesn't run,the great majority of time, ALL the startup command lines it's not my fault either.

The solution is moving it manually after launch, but on correction i can't do it.
